package com.packtpub.as7development.chapter3.exception;

public class SeatBookedException extends Exception {

	public SeatBookedException(String string) {
		super(string);
	}
	public SeatBookedException() {
		super();
	}
}
