package com.packtpub.as7development.chapter3.ejb;

 
 

public interface TheatreInfo {
	 public String printSeatList();

}
