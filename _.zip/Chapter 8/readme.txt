How to run the example:

mvn install jboss-as:deploy

mvn test �Pjunit
