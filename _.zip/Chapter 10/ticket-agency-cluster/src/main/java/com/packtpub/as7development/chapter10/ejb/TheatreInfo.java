package com.packtpub.as7development.chapter10.ejb;

 
 

public interface TheatreInfo {
	 public String printSeatList();

}
