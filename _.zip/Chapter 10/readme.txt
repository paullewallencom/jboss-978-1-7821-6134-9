How to deploy the ticket-agency-cluster
mvn install jboss-as:deploy

How to run the ticket-agency-cluster-client:
mvn install exec:exec
